# Responsive Internship Board — Edvyro Task 1

A beginner-friendly, responsive internship listing interface made with semantic HTML, CSS, and vanilla JavaScript (no framework or build step).

## Files
- `index.html` — page structure and accessible search/filter form
- `style.css` — responsive styling for mobile, tablet, and desktop
- `script.js` — internship cards, search, domain filtering, empty/error states, and keyboard-friendly interactions
- `internship-records-sample.json` — fictional sample internship records supplied for the task

## Run
Open `index.html` in a browser. For best results with the local JSON file, use a static host such as GitHub Pages. If the JSON file cannot be loaded, the app displays built-in fictional sample listings.

## Features
- Search internship titles and related details
- Filter by domain and clear filters
- Responsive layout and semantic HTML landmarks
- Keyboard-friendly controls, form labels, and live status announcements
- Empty state when no listings match
- Built-in fictional fallback data if the JSON file cannot load

## Test checklist
- [ ] Test at 360px mobile width
- [ ] Test at 768px tablet width
- [ ] Test at desktop width
- [ ] Search for a matching term and a term with no matches
- [ ] Change domain filter and clear filters
- [ ] Confirm keyboard navigation works

All internship entries are fictional demonstration data.
