"use strict";

    // Reusable sample data. These fictional records keep the board usable if the sample feed is unavailable.
    const fallbackInternships = [
      { id: 1, title: "Frontend Developer Intern", company: "BrightPixel Studio", domain: "Web Development", mode: "Remote", duration: "3 months", stipend: "₹8,000/month", description: "Build responsive pages, improve user interfaces, and learn from a small product team." },
      { id: 2, title: "AI/ML Intern", company: "NovaMind Labs", domain: "Artificial Intelligence", mode: "Hybrid", duration: "2 months", stipend: "₹10,000/month", description: "Explore beginner machine-learning workflows and help prepare clean sample datasets." },
      { id: 3, title: "Data Analyst Intern", company: "InsightWorks", domain: "Data Analytics", mode: "Remote", duration: "3 months", stipend: "₹7,000/month", description: "Organize sample data, create charts, and explain useful trends in simple reports." },
      { id: 4, title: "UI/UX Design Intern", company: "Mosaic Creative", domain: "Design", mode: "Hybrid", duration: "2 months", stipend: "₹6,000/month", description: "Create wireframes and accessible interface ideas for mobile and desktop products." },
      { id: 5, title: "Python Developer Intern", company: "CodeHarbor", domain: "Software Development", mode: "On-site", duration: "3 months", stipend: "₹9,000/month", description: "Practice Python fundamentals, write small scripts, and test simple features." },
      { id: 6, title: "Digital Marketing Intern", company: "SocialSpring", domain: "Marketing", mode: "Remote", duration: "2 months", stipend: "₹5,000/month", description: "Help plan content calendars and review engagement on fictional campaign reports." },
      { id: 7, title: "Cybersecurity Intern", company: "SafeStack Learning", domain: "Cybersecurity", mode: "Remote", duration: "3 months", stipend: "₹8,500/month", description: "Learn security basics and document safe, authorized practice-lab exercises." },
      { id: 8, title: "Cloud Support Intern", company: "SkyBridge Tech", domain: "Cloud Computing", mode: "Hybrid", duration: "3 months", stipend: "₹8,000/month", description: "Explore cloud concepts, write setup notes, and assist with sample deployment tasks." },
      { id: 9, title: "Mobile App Intern", company: "PocketPath Apps", domain: "App Development", mode: "On-site", duration: "2 months", stipend: "₹7,500/month", description: "Help test mobile layouts and document improvements to a sample application." }
    ];

    const listElement = document.getElementById("internship-list");
    const searchInput = document.getElementById("search-input");
    const domainFilter = document.getElementById("domain-filter");
    const clearButton = document.getElementById("clear-filters");
    const resultCount = document.getElementById("result-count");
    const statusMessage = document.getElementById("status-message");

    let internships = [];
    let feedWarning = "";

    function safeText(value, fallback = "Details coming soon") {
      return typeof value === "string" && value.trim() ? value.trim() : fallback;
    }

    function normaliseRecord(record, index) {
      // Accept common field names in the supplied sample data while keeping safe defaults.
      return {
        id: record.id ?? record.internship_id ?? index + 1,
        title: safeText(record.title || record.role || record.position, "Internship opportunity"),
        company: safeText(record.company || record.company_name || record.organization, "Sample organization"),
        domain: safeText(record.domain || record.category || record.field, "Other"),
        mode: safeText(record.mode || record.work_mode || record.location_type, "Not specified"),
        duration: safeText(record.duration || record.period, "Not specified"),
        stipend: safeText(record.stipend || record.salary || record.compensation, "Not specified"),
        description: safeText(record.description || record.summary, "Explore this sample internship opportunity.")
      };
    }

    function fillDomainOptions() {
      const domains = [...new Set(internships.map(item => item.domain))].sort((a, b) => a.localeCompare(b));
      domainFilter.replaceChildren(new Option("All domains", "all"));
      domains.forEach(domain => domainFilter.add(new Option(domain, domain)));
    }

    function makeCard(item) {
      const card = document.createElement("article");
      card.className = "card";

      const top = document.createElement("div");
      top.className = "card-top";
      const mark = document.createElement("div");
      mark.className = "company-mark";
      mark.setAttribute("aria-hidden", "true");
      mark.textContent = safeText(item.company, "LP").split(/\s+/).slice(0, 2).map(word => word[0]).join("").toUpperCase();
      const tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = item.domain;
      top.append(mark, tag);

      const heading = document.createElement("div");
      const title = document.createElement("h3");
      title.textContent = item.title;
      const company = document.createElement("p");
      company.className = "company";
      company.textContent = item.company;
      heading.append(title, company);

      const description = document.createElement("p");
      description.className = "description";
      description.textContent = item.description;

      const meta = document.createElement("div");
      meta.className = "meta";
      [item.mode, item.duration].forEach(value => {
        const chip = document.createElement("span");
        chip.textContent = value;
        meta.append(chip);
      });

      const footer = document.createElement("div");
      footer.className = "card-footer";
      const stipend = document.createElement("span");
      stipend.className = "stipend";
      stipend.textContent = item.stipend;
      const details = document.createElement("a");
      details.className = "details-link";
      details.href = "mailto:careers@example.com?subject=" + encodeURIComponent("Question about " + item.title);
      details.textContent = "Ask about role ↗";
      details.setAttribute("aria-label", "Ask a question about " + item.title + " at " + item.company);
      footer.append(stipend, details);

      card.append(top, heading, description, meta, footer);
      return card;
    }

    function render() {
      const query = searchInput.value.trim().toLocaleLowerCase();
      const selectedDomain = domainFilter.value;
      const matches = internships.filter(item => {
        const searchable = [item.title, item.company, item.domain, item.mode, item.duration, item.description].join(" ").toLocaleLowerCase();
        return searchable.includes(query) && (selectedDomain === "all" || item.domain === selectedDomain);
      });

      listElement.replaceChildren();
      if (matches.length === 0) {
        const empty = document.createElement("div");
        empty.className = "state";
        const title = document.createElement("strong");
        title.textContent = "No internships found";
        const message = document.createElement("span");
        message.textContent = "Try another keyword or choose “All domains”.";
        empty.append(title, message);
        listElement.append(empty);
        resultCount.textContent = "0 opportunities";
        statusMessage.textContent = "No internships match your filters.";
        return;
      }

      matches.forEach(item => listElement.append(makeCard(item)));
      resultCount.textContent = matches.length + (matches.length === 1 ? " opportunity" : " opportunities");
      statusMessage.textContent = matches.length + " internships shown.";
    }

    async function loadInternships() {
      try {
        // Load the supplied fictional JSON seed included in this repository.
        const response = await fetch("internship-records-sample.json", { headers: { "Accept": "application/json" } });
        if (!response.ok) throw new Error("The sample feed returned an unavailable response.");
        const data = await response.json();
        const records = Array.isArray(data) ? data : (data.internships || data.records || data.data);
        if (!Array.isArray(records) || records.length === 0) throw new Error("The sample feed did not contain a list of records.");
        internships = records.map(normaliseRecord);
      } catch (error) {
        internships = fallbackInternships.map(normaliseRecord);
        feedWarning = "The sample JSON could not be loaded, so built-in fictional examples are being shown instead.";
        console.warn("Using built-in internship examples:", error);
      }
      fillDomainOptions();
      render();
      if (feedWarning) {
        const note = document.createElement("p");
        note.className = "state";
        note.style.marginTop = "14px";
        note.textContent = feedWarning;
        listElement.before(note);
      }
    }

    searchInput.addEventListener("input", render);
    domainFilter.addEventListener("change", render);
    clearButton.addEventListener("click", () => {
      searchInput.value = "";
      domainFilter.value = "all";
      render();
      searchInput.focus();
    });
    document.getElementById("filter-form").addEventListener("submit", event => {
      event.preventDefault();
      render();
    });

    loadInternships().catch(error => {
      console.error(error);
      listElement.replaceChildren();
      const state = document.createElement("div");
      state.className = "state error";
      const title = document.createElement("strong");
      title.textContent = "We couldn't load the internship board";
      const message = document.createElement("span");
      message.textContent = "Please refresh the page. If the problem continues, check your connection.";
      state.append(title, message);
      listElement.append(state);
      resultCount.textContent = "Unable to load";
      statusMessage.textContent = "There was a problem loading internships.";
    });
